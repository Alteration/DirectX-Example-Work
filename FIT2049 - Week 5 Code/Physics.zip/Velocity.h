#ifndef VELOCITY_H
#define VELOCITY_H

#include "DirectXTK\SimpleMath.h"
#include <math.h>
using namespace DirectX::SimpleMath;

class Velocity
{
private:
	float TERMINAL_VELOCITY = 7.5f;
	float storedTimestep;
	float directionalityY;
	Vector3 axisVelocity;
	float drag;
	bool onGround = true;
public:
	Velocity() { axisVelocity = Vector3(0, 0, 0); drag = 0.9; };
	~Velocity();
	void increaseVelocity(Vector3 inc, float dir, float timestep);
	void decreaseVelocity(Vector3 dec);
	void offGround(bool status);
	void dragOn();
	
	//void setDirection(float dir) { directionalityY = dir; }
	Vector3 getVelocity() { return axisVelocity; }
};

#endif // !VELOCITY_H
